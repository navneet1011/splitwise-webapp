from django.contrib import admin
from .models import Post, Friend

admin.site.register(Post)
admin.site.register(Friend)